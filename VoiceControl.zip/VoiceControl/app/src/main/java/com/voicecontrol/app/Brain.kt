package com.voicecontrol.app

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Handler
import android.os.Looper

/**
 * সিদ্ধান্ত: অনলাইন + key থাকলে AI মোড, নইলে অফলাইন নিয়ম-ভিত্তিক মোড।
 */
object Brain {

    private val main = Handler(Looper.getMainLooper())

    @Volatile
    private var busy = false

    @Volatile
    private var pendingQuestion: String? = null

    fun prefs(ctx: Context) = ctx.getSharedPreferences("vc", Context.MODE_PRIVATE)

    fun apiKey(ctx: Context): String = prefs(ctx).getString("api_key", "")?.trim() ?: ""

    fun aiEnabled(ctx: Context): Boolean = prefs(ctx).getBoolean("ai_on", true)

    fun isAwaitingAnswer(): Boolean = pendingQuestion != null

    fun isOnline(ctx: Context): Boolean {
        return try {
            val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val net = cm.activeNetwork ?: return false
            val caps = cm.getNetworkCapabilities(net) ?: return false
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
        } catch (e: Exception) {
            false
        }
    }

    /** onProgress ও onFinal মূল (main) থ্রেডে ডাক পড়ে। */
    fun handle(
        ctx: Context,
        text: String,
        onProgress: (String) -> Unit,
        onFinal: (String) -> Unit
    ) {
        if (busy) {
            onFinal("আগের কাজ চলছে, একটু অপেক্ষা করুন")
            return
        }
        val app = ctx.applicationContext
        busy = true
        Thread {
            val result = try {
                process(app, text) { msg -> main.post { onProgress(msg) } }
            } catch (e: Exception) {
                "ত্রুটি: ${e.message}"
            } finally {
                busy = false
            }
            main.post { onFinal(result) }
        }.start()
    }

    private fun process(ctx: Context, text: String, progress: (String) -> Unit): String {
        val key = apiKey(ctx)
        val useAi = aiEnabled(ctx) && key.isNotEmpty() && isOnline(ctx)
        if (!useAi) {
            pendingQuestion = null
            return CommandProcessor.execute(ctx, text)
        }
        val pending = pendingQuestion
        pendingQuestion = null
        return try {
            val r = AiAgent.run(ctx, key, text, pending, progress)
            if (r.isQuestion) pendingQuestion = r.message
            r.message
        } catch (e: ApiKeyException) {
            "API key ঠিক নয়। অ্যাপ খুলে সঠিক key দিন"
        } catch (e: Exception) {
            "(অফলাইন মোড) " + CommandProcessor.execute(ctx, text)
        }
    }
}
