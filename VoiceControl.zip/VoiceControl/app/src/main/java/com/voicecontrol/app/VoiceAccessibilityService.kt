package com.voicecontrol.app

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class ScreenSnapshot(val pkg: String, val text: String, val nodes: List<AccessibilityNodeInfo>)

class VoiceAccessibilityService : AccessibilityService() {

    companion object {
        var instance: VoiceAccessibilityService? = null
    }

    private var windowManager: WindowManager? = null
    private var micButton: TextView? = null
    private var recognizer: SpeechRecognizer? = null
    private var lang = "bn-BD"
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        tts = TextToSpeech(this) { status -> ttsReady = status == TextToSpeech.SUCCESS }
        showOverlay()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        cleanup()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        cleanup()
        super.onDestroy()
    }

    private fun cleanup() {
        instance = null
        try {
            micButton?.let { windowManager?.removeView(it) }
        } catch (_: Exception) {
        }
        micButton = null
        recognizer?.destroy()
        recognizer = null
        tts?.shutdown()
        tts = null
        ttsReady = false
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    }

    private fun speak(msg: String) {
        val t = tts ?: return
        if (!ttsReady) return
        val bn = msg.any { it in '\u0980'..'\u09FF' }
        val r = t.setLanguage(if (bn) Locale("bn", "BD") else Locale.US)
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) return
        t.speak(msg, TextToSpeech.QUEUE_FLUSH, null, "vc")
    }

    // ---------- ভাসমান মাইক বাটন ----------
    private fun showOverlay() {
        if (micButton != null) return
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        windowManager = wm

        val btn = TextView(this).apply {
            text = "🎤"
            textSize = 26f
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#1565C0"))
            }
            setOnClickListener { startListening() }
            setOnLongClickListener {
                lang = if (lang == "bn-BD") "en-US" else "bn-BD"
                toast("ভাষা: " + if (lang == "bn-BD") "বাংলা" else "English")
                true
            }
        }

        val lp = WindowManager.LayoutParams(
            dp(60),
            dp(60),
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.END or Gravity.CENTER_VERTICAL
        lp.x = dp(8)

        wm.addView(btn, lp)
        micButton = btn
    }

    private fun setListeningUi(listening: Boolean) {
        micButton?.text = if (listening) "🔴" else "🎤"
    }

    // ---------- ভয়েস শোনা ----------
    private fun startListening(useLang: String = lang, retry: Boolean = true) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            toast("মাইক্রোফোনের অনুমতি দিন")
            val i = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            toast("এই ফোনে স্পিচ রিকগনিশন সার্ভিস নেই (Google অ্যাপ আপডেট করুন)")
            return
        }

        recognizer?.destroy()
        val sr = SpeechRecognizer.createSpeechRecognizer(this)
        sr.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}

            override fun onError(error: Int) {
                setListeningUi(false)
                if (error == SpeechRecognizer.ERROR_NO_MATCH && retry) {
                    startListening(if (useLang == "bn-BD") "en-US" else "bn-BD", false)
                    return
                }
                val msg = when (error) {
                    12, 13 -> "এই ভাষার ভয়েস প্যাক নেই। Google অ্যাপ > সেটিংস > ভয়েস > অফলাইন স্পিচ রিকগনিশন থেকে বাংলা ও English নামান"
                    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                        "ইন্টারনেট নেই, আর অফলাইন ভয়েস প্যাকও নেই"
                    else -> "শুনতে পাইনি, আবার চেষ্টা করুন (কোড $error)"
                }
                toast(msg)
            }

            override fun onResults(results: Bundle?) {
                setListeningUi(false)
                val text = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                if (text.isNullOrBlank()) {
                    toast("কিছু শুনতে পাইনি")
                    return
                }
                micButton?.text = "⏳"
                Brain.handle(
                    this@VoiceAccessibilityService,
                    text,
                    { progress -> toast(progress) },
                    { reply ->
                        micButton?.text = "🎤"
                        toast("\"$text\"\n→ $reply")
                        speak(reply)
                        if (Brain.isAwaitingAnswer()) {
                            Handler(Looper.getMainLooper()).postDelayed({ startListening() }, 3000)
                        }
                    }
                )
            }
        })
        recognizer = sr

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, useLang)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, !Brain.isOnline(this@VoiceAccessibilityService))
        }
        sr.startListening(intent)
        setListeningUi(true)
    }

    // ---------- স্ক্রিন নিয়ন্ত্রণ ----------
    fun global(action: Int): Boolean = performGlobalAction(action)

    fun clickByText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val nodes = root.findAccessibilityNodeInfosByText(text)
        for (n in nodes) {
            var cur: AccessibilityNodeInfo? = n
            while (cur != null) {
                if (cur.isClickable) {
                    return cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                }
                cur = cur.parent
            }
        }
        return false
    }

    fun typeText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        val args = Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    fun scroll(forward: Boolean): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = findScrollable(root) ?: return false
        val action = if (forward) {
            AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
        } else {
            AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        }
        return node.performAction(action)
    }

    fun pressEnter(): Boolean {
        if (Build.VERSION.SDK_INT < 30) return false
        val root = rootInActiveWindow ?: return false
        val node = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        return node.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
    }

    fun clickNode(n: AccessibilityNodeInfo): Boolean {
        var cur: AccessibilityNodeInfo? = n
        var depth = 0
        while (cur != null && depth < 8) {
            if (cur.isClickable) {
                return cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            }
            cur = cur.parent
            depth++
        }
        return false
    }

    fun setNodeText(n: AccessibilityNodeInfo, text: String): Boolean {
        n.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val args = Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        return n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    /** বর্তমান স্ক্রিনের তালিকা (AI-কে পাঠানোর জন্য)। */
    fun snapshot(): ScreenSnapshot? {
        val root = rootInActiveWindow ?: return null
        val nodes = ArrayList<AccessibilityNodeInfo>()
        val sb = StringBuilder()
        collect(root, nodes, sb)
        return ScreenSnapshot(root.packageName?.toString() ?: "", sb.toString(), nodes)
    }

    private fun collect(n: AccessibilityNodeInfo, nodes: MutableList<AccessibilityNodeInfo>, sb: StringBuilder) {
        if (nodes.size >= 80) return
        if (n.isVisibleToUser) {
            val label = (n.text?.toString() ?: n.contentDescription?.toString() ?: "").trim().take(60)
            val leafIcon = n.isClickable && n.childCount == 0
            if (label.isNotEmpty() || n.isEditable || leafIcon) {
                val flags = ArrayList<String>()
                if (n.isClickable) flags.add("click")
                if (n.isEditable) flags.add("edit")
                if (n.isScrollable) flags.add("scroll")
                if (n.isChecked) flags.add("checked")
                val shown = if (n.isPassword) "(hidden)" else label
                sb.append('[').append(nodes.size).append("] ").append(shown)
                if (flags.isNotEmpty()) sb.append(" {").append(flags.joinToString(",")).append('}')
                sb.append('\n')
                nodes.add(n)
            }
        }
        for (i in 0 until n.childCount) {
            val c = n.getChild(i) ?: continue
            collect(c, nodes, sb)
        }
    }

    private fun findScrollable(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (n.isScrollable) return n
        for (i in 0 until n.childCount) {
            val c = n.getChild(i) ?: continue
            val r = findScrollable(c)
            if (r != null) return r
        }
        return null
    }
}
