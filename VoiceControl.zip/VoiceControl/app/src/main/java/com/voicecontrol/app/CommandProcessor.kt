package com.voicecontrol.app

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.Build
import android.provider.AlarmClock
import android.provider.Settings

/**
 * ভয়েস টেক্সট -> ফোনের কাজ।
 * এখন নিয়ম-ভিত্তিক (keyword) ; পরে এখানে LLM (Claude API) যোগ করা যাবে।
 */
object CommandProcessor {

    private val appAliases = listOf(
        "হোয়াটসঅ্যাপ" to "whatsapp", "হোয়াটস অ্যাপ" to "whatsapp", "হোয়াটসএপ" to "whatsapp",
        "ফেসবুক" to "facebook", "মেসেঞ্জার" to "messenger", "ইউটিউব" to "youtube",
        "ক্রোম" to "chrome", "ক্যামেরা" to "camera", "গ্যালারি" to "gallery",
        "সেটিংস" to "settings", "সেটিং" to "settings", "ক্যালকুলেটর" to "calculator",
        "ফোন" to "phone", "গুগল" to "google", "টেলিগ্রাম" to "telegram", "ইমো" to "imo",
        "বিকাশ" to "bkash", "নগদ" to "nagad", "ইনস্টাগ্রাম" to "instagram",
        "টিকটক" to "tiktok", "ম্যাপ" to "maps", "ঘড়ি" to "clock",
        "ক্যালেন্ডার" to "calendar", "জিমেইল" to "gmail", "প্লে স্টোর" to "play store"
    )

    private val openWords = setOf(
        "খোলো", "খুলো", "খুলুন", "খোল", "ওপেন", "open", "চালু", "চালাও", "launch", "start"
    )
    private val clickWords = setOf("ক্লিক", "ট্যাপ", "চাপো", "চাপ", "টিপো", "click", "tap", "press")
    private val typeWords = setOf("লেখো", "লিখো", "লিখুন", "টাইপ", "type", "write")
    private val fillers = setOf(
        "করো", "কর", "করুন", "দাও", "দিন", "এ", "তে", "কে", "এর", "the", "please", "প্লিজ", "a"
    )

    private fun digits(s: String): String = buildString {
        for (c in s) append(if (c in '০'..'৯') ('0' + (c - '০')) else c)
    }

    private fun has(t: String, vararg keys: String) = keys.any { t.contains(it) }

    private fun tokensWithout(raw: String, vararg sets: Set<String>): List<String> =
        raw.trim().split(Regex("\\s+")).filter { tok ->
            sets.none { it.contains(tok.lowercase()) }
        }

    fun execute(ctx: Context, raw: String): String {
        return try {
            run(ctx, digits(raw).trim())
        } catch (e: Exception) {
            "ত্রুটি: ${e.message}"
        }
    }

    private fun run(ctx: Context, raw: String): String {
        val t = raw.lowercase()
        val svc = VoiceAccessibilityService.instance

        // টর্চ
        if (has(t, "টর্চ", "ফ্ল্যাশ", "torch", "flashlight")) {
            val off = has(t, "নেভা", "বন্ধ", "off")
            return torch(ctx, !off)
        }
        // সেটিংস প্যানেল
        if (has(t, "ওয়াইফাই", "ওয়াই-ফাই", "wifi", "wi-fi")) {
            return startSettings(ctx, Settings.ACTION_WIFI_SETTINGS, "ওয়াইফাই সেটিংস খোলা হলো")
        }
        if (has(t, "ব্লুটুথ", "bluetooth")) {
            return startSettings(ctx, Settings.ACTION_BLUETOOTH_SETTINGS, "ব্লুটুথ সেটিংস খোলা হলো")
        }
        // অ্যালার্ম
        if (has(t, "অ্যালার্ম", "এলার্ম", "alarm")) return alarm(ctx, t)
        // কল
        if (has(t, "কল", "call", "ফোন করো", "dial")) {
            val m = Regex("\\+?\\d[\\d\\s\\-]{5,}\\d").find(t)
            if (m != null) {
                val number = m.value.filter { it.isDigit() || it == '+' }
                return launch(ctx, Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number")), "ডায়াল: $number")
            }
            return "কোন নম্বরে কল করব? নম্বরসহ বলুন"
        }

        // নিচের কমান্ডগুলোর জন্য অ্যাক্সেসিবিলিটি সার্ভিস লাগবে
        val needs = "অ্যাক্সেসিবিলিটি সার্ভিস চালু করুন"

        if (has(t, "হোম", "home screen", "go home") || t == "home") {
            return svc?.let { done(it.global(AccessibilityService.GLOBAL_ACTION_HOME), "হোমে গেলাম") } ?: needs
        }
        if (has(t, "পিছনে", "পেছনে", "ব্যাক", "back")) {
            return svc?.let { done(it.global(AccessibilityService.GLOBAL_ACTION_BACK), "পিছনে গেলাম") } ?: needs
        }
        if (has(t, "রিসেন্ট", "সব অ্যাপ", "recent")) {
            return svc?.let { done(it.global(AccessibilityService.GLOBAL_ACTION_RECENTS), "রিসেন্ট অ্যাপ") } ?: needs
        }
        if (has(t, "নোটিফিকেশন", "notification")) {
            return svc?.let { done(it.global(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS), "নোটিফিকেশন খুললাম") } ?: needs
        }
        if (has(t, "স্ক্রিন লক", "লক করো", "lock screen")) {
            return if (Build.VERSION.SDK_INT >= 28) {
                svc?.let { done(it.global(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN), "স্ক্রিন লক") } ?: needs
            } else "এই অ্যান্ড্রয়েড ভার্সনে লক সাপোর্ট নেই"
        }
        if (has(t, "স্ক্রল ডাউন", "scroll down", "নিচে")) {
            return svc?.let { done(it.scroll(true), "নিচে স্ক্রল করলাম") } ?: needs
        }
        if (has(t, "স্ক্রল আপ", "scroll up", "উপরে", "ওপরে")) {
            return svc?.let { done(it.scroll(false), "উপরে স্ক্রল করলাম") } ?: needs
        }

        // টাইপ
        if (typeWords.any { t.split(Regex("\\s+")).contains(it) }) {
            val text = tokensWithout(raw, typeWords, fillers).joinToString(" ")
            return svc?.let { done(it.typeText(text), "লিখলাম: $text") } ?: needs
        }
        // ক্লিক
        if (clickWords.any { t.split(Regex("\\s+")).contains(it) }) {
            val target = tokensWithout(raw, clickWords, fillers).joinToString(" ")
            return svc?.let { done(it.clickByText(target), "ক্লিক: $target") } ?: needs
        }

        // অ্যাপ খোলা (কীওয়ার্ডসহ অথবা শুধু অ্যাপের নাম)
        val target = tokensWithout(raw, openWords, fillers).joinToString(" ")
        return openApp(ctx, target)
    }

    private fun done(ok: Boolean, msg: String) = if (ok) msg else "কাজটি করা গেল না"

    private fun launch(ctx: Context, i: Intent, okMsg: String): String {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
        return okMsg
    }

    private fun startSettings(ctx: Context, action: String, msg: String) =
        launch(ctx, Intent(action), msg)

    private fun openApp(ctx: Context, targetRaw: String): String {
        if (targetRaw.isBlank()) return "কোন অ্যাপ খুলব?"
        val target = targetRaw.lowercase()
        var query = target
        for ((bn, en) in appAliases) {
            if (target.contains(bn)) {
                query = en
                break
            }
        }
        val pm = ctx.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(main, 0)
        val match = apps.firstOrNull {
            val label = it.loadLabel(pm).toString().lowercase()
            label.contains(query) || query.contains(label) && label.length > 2
        } ?: return "বুঝতে পারিনি: \"$targetRaw\""
        val intent = pm.getLaunchIntentForPackage(match.activityInfo.packageName)
            ?: return "অ্যাপ খোলা গেল না"
        return launch(ctx, intent, "খুলছি: ${match.loadLabel(pm)}")
    }

    private fun alarm(ctx: Context, t: String): String {
        val m = Regex("(\\d{1,2})(?:[:.](\\d{2}))?").find(t) ?: return "কয়টায় অ্যালার্ম দেব বলুন"
        var h = m.groupValues[1].toInt()
        val min = m.groupValues[2].ifEmpty { "0" }.toInt()
        if (has(t, "বিকাল", "সন্ধ্যা", "রাত", "pm", "evening", "night") && h < 12) h += 12
        if (h == 12 && has(t, "রাত")) h = 0
        if (h > 23 || min > 59) return "সময়টা বুঝতে পারিনি"
        val i = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, h)
            putExtra(AlarmClock.EXTRA_MINUTES, min)
            putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        }
        return launch(ctx, i, "অ্যালার্ম সেট: %02d:%02d".format(h, min))
    }

    private fun torch(ctx: Context, on: Boolean): String {
        return try {
            val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.first {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
            cm.setTorchMode(id, on)
            if (on) "টর্চ জ্বালালাম" else "টর্চ নেভালাম"
        } catch (e: Exception) {
            "টর্চ চালানো গেল না"
        }
    }
}
