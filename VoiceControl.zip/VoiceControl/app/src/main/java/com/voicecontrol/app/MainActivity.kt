package com.voicecontrol.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var log: TextView
    private lateinit var input: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }

        root.addView(TextView(this).apply {
            text = "🎤 ভয়েস কন্ট্রোল"
            textSize = 24f
            setTypeface(typeface, Typeface.BOLD)
        })

        status = TextView(this).apply {
            textSize = 15f
            setPadding(0, pad, 0, pad)
        }
        root.addView(status)

        root.addView(button("১. মাইক্রোফোন অনুমতি দিন") {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
        })
        root.addView(button("২. অ্যাক্সেসিবিলিটি চালু করুন") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(button("অ্যাপ ইনফো (Restricted settings অনুমতির জন্য)") {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                    .setData(android.net.Uri.parse("package:$packageName"))
            )
        })

        root.addView(TextView(this).apply {
            text = "\nমাইক ছাড়া পরীক্ষা করুন:"
            textSize = 15f
        })
        input = EditText(this).apply {
            hint = "যেমন: ইউটিউব খোলো"
            setSingleLine()
        }
        root.addView(input)
        root.addView(button("চালাও") {
            val cmd = input.text.toString()
            if (cmd.isNotBlank()) {
                val reply = CommandProcessor.execute(this, cmd)
                log.text = "\"$cmd\"\n→ $reply\n\n" + log.text
            }
        })

        log = TextView(this).apply {
            textSize = 14f
            setPadding(0, pad, 0, pad)
        }
        root.addView(log)

        root.addView(TextView(this).apply {
            textSize = 14f
            text = "উদাহরণ কমান্ড:\n" +
                "• হোয়াটসঅ্যাপ খোলো / open chrome\n" +
                "• ০১৭১২৩৪৫৬৭৮ নম্বরে কল করো\n" +
                "• সকাল ৬:৩০ এ অ্যালার্ম দাও\n" +
                "• টর্চ জ্বালাও / টর্চ নেভাও\n" +
                "• ওয়াইফাই, ব্লুটুথ\n" +
                "• হোম, পিছনে, রিসেন্ট, নোটিফিকেশন\n" +
                "• নিচে স্ক্রল করো / উপরে\n" +
                "• Search এ ক্লিক করো\n" +
                "• hello লেখো (কীবোর্ড খোলা থাকলে)\n\n" +
                "সার্ভিস চালু হলে স্ক্রিনের ডান পাশে ভাসমান 🎤 বাটন আসবে। " +
                "ট্যাপ করে কথা বলুন। বাটন চেপে ধরলে বাংলা ↔ English বদলাবে।"
        })

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refreshStatus()
    }

    private fun refreshStatus() {
        val mic = checkSelfPermission(Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        val svc = VoiceAccessibilityService.instance != null
        status.text = (if (mic) "✅" else "❌") + " মাইক্রোফোন অনুমতি\n" +
            (if (svc) "✅" else "❌") + " অ্যাক্সেসিবিলিটি সার্ভিস"
    }

    private fun button(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener { onClick() }
    }
}
