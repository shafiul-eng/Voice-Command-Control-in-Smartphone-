# ভয়েস কন্ট্রোল (Android)

বাংলা/English ভয়েস কমান্ডে ফোন চালানোর প্রোটোটাইপ।

- Kotlin, কোনো বাইরের লাইব্রেরি ছাড়া
- AccessibilityService + ভাসমান মাইক বাটন + SpeechRecognizer
- `CommandProcessor.kt` এ কমান্ড লজিক (পরে Claude API যোগ করার জায়গা)

বিল্ড: GitHub Actions (`.github/workflows/build.yml`) বা Android Studio।
